package com.example.first_cry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
